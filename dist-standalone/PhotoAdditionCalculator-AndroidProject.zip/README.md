# Photo Addition Calculator - Android Project

This is the official native Android project for Photo Addition Calculator.

## How to Build the APK File

### Option 1: Using Android Studio (Easiest)
1. Open **Android Studio**.
2. Click **Open** and select this extracted folder.
3. Wait for Gradle sync to finish (1-2 minutes).
4. In the top menu, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Once built, a popup will appear at the bottom right: click **locate** to open the folder containing `app-debug.apk`.
6. Transfer `app-debug.apk` to your phone or emulator and install!

### Option 2: Using Command Line (Gradle)
```bash
./gradlew assembleDebug
```
The output APK file will be at:
`app/build/outputs/apk/debug/app-debug.apk`

For release APK:
```bash
./gradlew assembleRelease
```
